function device_showcase_theme_enqueue_styles() {
    wp_enqueue_style('bootstrap-css', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
}

add_action('wp_enqueue_scripts', 'device_showcase_theme_enqueue_styles');
