<?php get_header(); ?>


    <div class="container">
        <h1 class="text-center my-4">INTEGRATED DEVICES</h1>
        <div class="row">
            <div class="col-md-3">
                <div class="card mb-4">
                    <img src="devices/a7e19339-e8fc-4167-9ce3-2cab544b855f.jpeg.jpg" alt="Device 1">
                    <div class="card-body">
                        <h5 class="card-title">SMART EYEWEAR</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card mb-4">
                    <img src="devices/Syringe-pump-150x150.png" alt="Device 2">
                    <div class="card-body">
                        <h5 class="card-title">SYRINGE-PUMP</h5>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card mb-4">
                    <img src="devices/Stethoscope.WEBP" alt="Device 4">
                    <div class="card-body">
                        <h5 class="card-title">STHETHSCOPE</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card mb-4">
                    <img src="devices/bloodgas.jpg" alt="Device 5">
                    <div class="card-body">
                        <h5 class="card-title">DIGITAL BLOOD GAS INSTRUMENT</h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <div class="card mb-4">
                    <img src="devices/pointofcaredevices.JPG" alt="Device 6">
                    <div class="card-body">
                        <h5 class="card-title">POINT OF CARE DEVICES</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card mb-4">
                    <img src="devices/Hand Held Ultrasound.PNG" alt="Device 7">
                    <div class="card-body">
                        <h5 class="card-title">HANDHELD ULTRASOUND</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card mb-4">
                    <img src="devices/ventilators.jpg" alt="Device 8">
                    <div class="card-body">
                        <h5 class="card-title">VENTILATORS</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card mb-4">
                    <img src="devices/patient monitor 02.jpg" alt="Device 9">
                    <div class="card-body">
                        <h5 class="card-title">PATIENT MONITOR</h5>
                    </div>
                </div>
            </div>
          
        </div>
       
    </div>

<?php get_footer(); ?>
