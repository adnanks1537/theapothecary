<footer class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/Asset 4.png" alt="Footer Logo" height="50">
                </div>
                <div class="col-md-6">
                    <ul class="list-unstyled">
                        <li><a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a></li>
                        <li><a href="<?php echo esc_url(home_url('/terms-of-service')); ?>">Terms of Service</a></li>
                        <li><a href="<?php echo esc_url(home_url('/contact')); ?>">Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <ul class="list-inline social-icons">
                        <!-- Add social media links here -->
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <?php wp_footer(); ?>
</body>
</html>
