    <!-- Your footer content goes here -->
    <?php wp_footer(); // Enqueue WordPress scripts ?>
</body>
</html>
