<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php wp_title(''); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); // Enqueue WordPress scripts and styles ?>
</head>
<body>
    <!-- Your header content goes here -->
