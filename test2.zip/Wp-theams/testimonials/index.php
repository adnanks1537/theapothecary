<?php
get_header(); // Include the header template
?>

<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <div class="container-fluid px-3 px-sm-5 my-5 text-center">
                <h2 class="text-white">Testimonials</h2>
            </div>
            <div id="customers-testimonials" class="owl-carousel">

                <!--TESTIMONIAL 1 -->
                <div class="item shadow-lg">
                    <div class="p-4 bg-white rounded">
                        <img src="testimonials/Sasi-Tharoor-removebg-preview.png" alt="">
                        <div class="commo pt-3"><img src="https://annedece.sirv.com/Images/commo6.png"></div>
                        <p class="mb-4 text-muted">India’s First Initiative that too from kerala is indeed a matter of pride for me to inaugurate.Especially being a Malayalee. I wholeheartedly commend Apothecary Medical Services for their exceptional use of health technology to improve the lives of people. Their dedication to leveraging innovation for the betterment of society, while upholding ethical principles, is truly laudable. Through their pioneering efforts, Apothecary has demonstrated that technology, when used responsibly and with compassion, has the potential to transform healthcare and positively impact countless lives.</p>
                        <hr>
                        <div class="d-flex align-items-center">
                            <div class="author-img mr-3"> <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Sasi-Tharoor-1.jpg"> </div>
                            <div>
                                <h6 class="m-0 float-left font-weight-bold text-warning">Shashi Tharoor</h6>
                                <p class="m-0 small font-medium text-muted">Web Developer</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!--END OF TESTIMONIAL 1 -->
                <!--TESTIMONIAL 2 -->
                <div class="item shadow-lg">
                    <div class="p-4 bg-white rounded">
                        <img src="https://annedece.sirv.com/Images/cod-lab.png" alt="">
                        <div class="commo pt-3"><img src="https://annedece.sirv.com/Images/commo6.png"></div>
                        <p class="mb-4 text-muted">Aster Group takes great pride in the association with Apothecary Medical Services led by Dr Nadeem. The innovation they have brought to emergency medicine aligns perfectly with our mission to deliver quality healthcare that is accessible, affordable, and compassionate. Apothecary's contributions have not only strengthened the emergency healthcare services within the Aster Group but have also raised the bar for the entire industry, inspiring others to strive for excellence.</p>
                        <hr>
                        <div class="d-flex align-items-center">
                            <div class="author-img mr-3"> <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Azad-Moopen-1.jpg"> </div>
                            <div>
                                <h6 class="m-0 float-left font-weight-bold text-warning">Azad Moopen</h6>
                                <p class="m-0 small font-medium text-muted">Chairman, Aster Group</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!--END OF TESTIMONIAL 2 -->
                <!--TESTIMONIAL 3 -->
                <div class="item shadow-lg">
                    <div class="p-4 bg-white rounded">
                        <img src="https://annedece.sirv.com/Images/tvit.png" alt="">
                        <div class="commo pt-3"><img src="https://annedece.sirv.com/Images/commo6.png"></div>
                        <p class="mb-4 text-muted">I am delighted to share my heartfelt appreciation for Apothecary and the immense pride I feel for having given them the opportunity to bring their dream to life. Their commitment to empowering individuals and nurturing innovation is truly admirable. I am incredibly proud to be associated with Apothecary and to be a reason to share their vision with the world. Together, we are making a difference and ensuring that no dream goes unheard.</p>
                        <hr>
                        <div class="d-flex align-items-center">
                            <div class="author-img mr-3"> <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Farhan-Yasin-1.jpg"> </div>
                            <div>
                                <h6 class="m-0 float-left font-weight-bold text-warning">FARHAN YASIN</h6>
                                <p class="m-0 small font-medium text-muted">Aster India Vice President</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!--END OF TESTIMONIAL 3 -->
                <!--TESTIMONIAL 4 -->
                <div class="item shadow-lg">
                    <div class="p-4 bg-white rounded">
                        <img src="https://annedece.sirv.com/Images/lighting.png" alt="">
                        <div class="commo pt-3"><img src="https://annedece.sirv.com/Images/commo6.png"></div>
                        <p class="mb-4 text-muted">Dramatically maintain clicks-and-mortar solutions without functional solutions. Completely synergize resource taxing relationships via premier niche markets. Professionally cultivate.</p>
                        <hr>
                        <div class="d-flex align-items-center">
                            <div class="author-img mr-3"> <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Sreekandan-Nair-1.jpg"> </div>
                            <div>
                                <h6 class="m-0 float-left font-weight-bold text-warning">SREEKANDAN NAIR</h6>
                                <p class="m-0 small font-medium text-muted">Managing Director, Flowers channel and Media Fame</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!--END OF TESTIMONIAL 4 -->

            </div>
        </div>
    </div>
</div>

<!-- END OF TESTIMONIALS -->


<!-- Swipe buttons -->
<div class="container text-center mt-3">
    <a class="btn btn-primary" id="prevButton" >Previous</a>
    <a class="btn btn-primary" id="nextButton">Next</a>
</div>

<section class="section bg-white" id="section5">
                        <div class="process-heading text-center mb-5 text-danger">
                            <h3 class="text-uppercase"><b>NEWS & Updates</b></h3>
                            <p class="text-muted" > </p>
                        </div>
                        <div class="container h-100 d-flex align-items-center">
                            <div class="row">
                                <div class="col-lg-4 col-md-6 vv">
                                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Screenshot-2023-06-22-at-1.39.07-AM-1536x863-1.png" class="rounded img-fluid">
                                    <h5 class="mb-3 mt-5">Kerala:Aluva to start first AR Ambulance</h5>
                                    <!-- <p class="mb-4 text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ut mattis metus, id accumsan erat.</p>
                                    <a href="" class="btn btn-link">View More &rarr;</a> -->
                                    </div>
                                    <div class="col-lg-4 col-md-6 vv">
                                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/img4.png" class="rounded img-fluid">
                                    <h5 class="mb-3 mt-5">Indias 1st Assisted reality enabled smart ambulance launched</h5>
                                     <!-- <p class="mb-4 text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ut mattis metus, id accumsan erat.</p>
                                    <a href="" class="btn btn-link">View More &rarr;</a> -->
                                    </div>
                                    <div class="col-lg-4 col-md-6 vv">
                                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/image3.png" class="rounded img-fluid">
                                        <h5 class="mb-3 mt-5">Indias 1st Assisted reality enabled smart ambulance launched</h5>
                                         <!-- <p class="mb-4 text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ut mattis metus, id accumsan erat.</p>
                                        <a href="" class="btn btn-link">View More &rarr;</a> -->
                                        </div>
                                <div class="col-lg-4 col-md-6 vv">
                                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Screenshot-2023-06-22-at-1.39.49-AM-1536x863-1.png" class="rounded img-fluid">
                                    <h5 class="mb-3 mt-5">Aster Medicity implements  India's first Assisted Reality enabled smart ambulance launched</h5>
                                   <!-- <p class="mb-4 text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ut mattis metus, id accumsan erat.</p>
                                    <a href="" class="btn btn-link">View More &rarr;</a> -->
                                    </div>
                            </div>
                        </div>
                    </section>
<?php
get_footer(); // Include the footer template
?>
