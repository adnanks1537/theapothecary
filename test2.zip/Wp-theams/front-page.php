<?php
/* Template Name: Custom Front Page */
get_header();
?>

<header class="text-center"> <!-- Center align the content in the header -->
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <div class="container">
                            <a class="navbar-brand" href="#">
                                <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/logos-appo.png" alt="Logo" class="img-fluid"> <!-- Add your logo image -->
                            </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav ml-auto">
    <li class="nav-item">
        <a class="nav-link" href="<?php echo esc_url(home_url('/')); ?>">Home</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo esc_url(home_url('/about/index.php')); ?>">About</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo esc_url(home_url('/testimonials/index.php')); ?>">Testimonials</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo esc_url(home_url('/contact/')); ?>">Contact</a>
    </li>
</ul>
                            </div>
                        </div>
                    </nav>
                </header>

<main>
                <section class="section video-section" id="section1">
    <video autoplay loop muted poster="your-poster-image.jpg">
        <source src="http://theapothecary.co.in/wp-content/uploads/2023/10/apoc-002.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>
   
            
            <div class="col-lg-6 ml-auto align-items-center ">
                <!-- Right side of the section (text, image, and button) -->
                <div class="text-center mb-5 position:relative">
                    <img src="your-image.png" alt="Image" style="width: 100px; height: 100px;">
                    <div class="process-heading text-center text-danger">
                        <h3 class="text-uppercase"><b>Key Features</b></h3>
                        <p class="text-muted"></p>
                    </div>
                    <a href="learn-more-link" class="btn btn-primary  custom-button">Learn More</a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="use-cases-section" style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/bg2.jpg');">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <div class="card-use-cases">
                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/AMBULANCE-VEIW-1.jpg" class="card-img-top">
                    <div class="card-body d-flex flex-column align-items-center justify-content-center">
                        <h5 class="card-title text-danger"><b>Road Ambulance</b></h5>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <div class="card-use-cases">
                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/HELICOPTOR-1.jpg" class="card-img-top">
                    <div class="card-body d-flex flex-column align-items-center justify-content-center">
                        <h5 class="card-title text-danger"><b>Air Ambulacne</b></h5>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <div class="card-use-cases">
                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/WATERAMBULANCE-1.jpg" class="card-img-top">
                    <div class="card-body d-flex flex-column align-items-center justify-content-center">
                        <h5 class="card-title text-danger"><b>Water Ambulance</b></h5>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <div class="card-use-cases">
                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/MOBILEACCESS-1.jpg" class="card-img-top">
                    <div class="card-body d-flex flex-column align-items-center justify-content-center">
                        <h5 class="card-title text-danger"><b>Smart Emergency</b></h5>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <div class="card-use-cases">
                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/MOBILEACCESS-1.jpg" class="card-img-top">
                    <div class="card-body d-flex flex-column align-items-center justify-content-center">
                        <h5 class="card-title text-danger"><b>Tele ICU</b></h5>
                    </div>
                </div>
            </div>

           <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <div class="card-use-cases">
                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/SMARTICU-1.jpg" class="card-img-top">
                    <div class="card-body d-flex flex-column align-items-center justify-content-center">
                        <h5 class="card-title text-danger"><b>Smart Clinics</b></h5>
                    </div>
                </div>
            </div>
            <!-- Repeat the above card structure for other use cases as needed -->
        </div>
    </div>
</section>

<section class="section video-section" id="section3">
    <video autoplay loop muted poster="<?php echo get_template_directory_uri(); ?>/your-poster-image.jpg" id="bgVideo">
        <source src="http://theapothecary.co.in/wp-content/uploads/2023/10/ecgpulse-1.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>
    <div class="container h-100 d-flex align-items-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <div class="process-heading text-center mb-5 text-danger">
                        <h3 class="text-uppercase"><b>Key Features</b></h3>
                        <p class="text-muted"></p>
                    </div>
                </div><!--end col-->
            </div><!--end row-->
            <div class="row">
                <!-- Repeat the following process-box structure for other items -->
                <div class="col-lg-3 col-md-6">
                    <div class="process-box card text-center border-0 mt-4">
                        <div class="mb-3 pb-2">
                            <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/aitech-1-scaled.jpg" alt="01" class="img-fluid">
                        </div>
                        <div class="process-icon f-24">
                            <i class="mdi mdi-chevron-double-right"></i>
                        </div>
                        <a href="#" class="process-title text-uppercase mt-3"><h6>AI-ENHANCED DIAGNOSTICS</h6></a>
                        <div class="card-body rounded mt-3 border py-4">
                            <p class="text-muted mb-0">AI-Enhanced Diagnostics: With DICOM connectivity and powerful Artificial Intelligence, we elevate diagnostics and decision-making, enhancing the quality of your healthcare solutions.</p>
                        </div>
                    </div><!--end process-box-->
                </div><!--end col-->
                <!-- Repeat the above process-box structure for other items -->
                <div class="col-lg-3 col-md-6">
                    <div class="process-box card text-center border-0 mt-4">
                        <div class="mb-3 pb-2">
                            <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/care-1.jpg" alt="01" class="img-fluid">
                        </div>
                        <div class="process-icon f-24">
                            <i class="mdi mdi-chevron-double-right"></i>
                        </div>
                        <a href="#" class="process-title text-uppercase mt-3"><h6>COMPREHENSIVE PATIENT CARE</h6></a>
                        <div class="card-body rounded mt-3 border py-4">
                            <p class="text-muted mb-0">Experience seamless integration with a wide range of medical devices, ensuring comprehensive care for patients.</p>
                        </div>
                    </div><!--end process-box-->
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="process-box card text-center border-0 mt-4">
                        <div class="mb-3 pb-2">
                            <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/certified-1-scaled.jpg" alt="01" class="img-fluid">
                        </div>
                        <div class="process-icon f-24">
                            <i class="mdi mdi-chevron-double-right"></i>
                        </div>
                        <a href="#" class="process-title text-uppercase mt-3"><h6>CERTIFIED DIGITAL DIAGNOSTICS</h6></a>
                        <div class="card-body rounded mt-3 border py-4">
                            <p class="text-muted mb-0">We offer FDA/CE certified digital diagnostic devices for secure, compliant, and encrypted data transmission, guaranteeing the safety of your health data.</p>
                        </div>
                    </div><!--end process-box-->
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="process-box card text-center border-0 mt-4">
                        <div class="mb-3 pb-2">
                            <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/cutting-1.jpg" alt="01" class="img-fluid">
                        </div>
                        <div class="process-icon f-24">
                            <i class="mdi mdi-chevron-double-right"></i>
                        </div>
                        <a href="#" class="process-title text-uppercase mt-3"><h6>CUTTING-EDGE HEALTHCARE SOLUTION</h6></a>
                        <div class="card-body rounded mt-3 border py-4">
                            <p class="text-muted mb-0">Our advanced healthcare solution incorporates Assisted Reality Smart Glasses, ensuring expert support and guidance.</p>
                        </div>
                    </div><!--end process-box-->
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="process-box card text-center border-0 mt-4">
                        <div class="mb-3 pb-2">
                            <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/electronic-1-scaled.jpg" alt="01" class="img-fluid">
                        </div>
                        <div class="process-icon f-24">
                            <i class="mdi mdi-chevron-double-right"></i>
                        </div>
                        <a href="#" class="process-title text-uppercase mt-3"><h6> ELECTRONIC MEDICAL RECORDS ACCESS</h6></a>
                        <div class="card-body rounded mt-3 border py-4">
                            <p class="text-muted mb-0">Access Electronic Medical Records for future reference and continuous care, enhancing the quality of your healthcare journey.</p>
                        </div>
                    </div><!--end process-box-->
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="process-box card text-center border-0 mt-4">
                        <div class="mb-3 pb-2">
                            <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/ultrasound-1.jpg" alt="01" class="img-fluid">
                        </div>
                        <div class="process-icon f-24">
                            <i class="mdi mdi-chevron-double-right"></i>
                        </div>
                        <a href="#" class="process-title text-uppercase mt-3"><h6> REAL-TIME ULTRASOUND DIAGNOSTICS</h6></a>
                        <div class="card-body rounded mt-3 border py-4">
                            <p class="text-muted mb-0">Benefit from live multi-window ultrasound capabilities, enabling real-time diagnostics for better healthcare decisions.</p>
                        </div>
                    </div><!--end process-box-->
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="process-box card text-center border-0 mt-4">
                        <div class="mb-3 pb-2">
                            <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/video-call-1.jpg" alt="01" class="img-fluid">
                        </div>
                        <div class="process-icon f-24">
                            <i class="mdi mdi-chevron-double-right"></i>
                        </div>
                        <a href="#" class="process-title text-uppercase mt-3"><h6>CLICK AND CollABORATE REMOTE VIDEO ASSISTANCE</h6></a>
                        <div class="card-body rounded mt-3 border py-4">
                            <p class="text-muted mb-0">Utilize our remote video assistance with advanced features like location tracking and annotation, simplifying communication with healthcare experts.</p>
                        </div>
                    </div><!--end process-box-->
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="process-box card text-center border-0 mt-4">
                        <div class="mb-3 pb-2">
                            <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/video-consultance-1.jpg" alt="01" class="img-fluid">
                        </div>
                        <div class="process-icon f-24">
                            <i class="mdi mdi-chevron-double-right"></i>
                        </div>
                        <a href="#" class="process-title text-uppercase mt-3"><h6>VIDEO CONSULTATION AND CONFERENCE</h6></a>
                        <div class="card-body rounded mt-3 border py-4">
                            <p class="text-muted mb-0">Enjoy video consultations and conferences over 4G, 5G, Satellite, and LAN networks, ensuring easy access to healthcare expertise.</p>
                        </div>
                    </div><!--end process-box-->
                </div>

                
            </div><!--end row-->
        </div><!--end container-->
    </div>
</section>
<section class="section bg-danger key-features-section" style="position: relative;" id="section4">
                        <div class="process-heading text-center mb-5 text-white">
                            <h3 class="text-uppercase"><b>InTEGRATED DEVICES </b></h3>
                            <p class="text-muted" > </p>
                        </div>
                        <div class="container h-100 d-flex align-items-center">
                            
                            <div class="card-container">
                                <div class="row">
                                  <div class="new-card">
                                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/a7e19339-e8fc-4167-9ce3-2cab544b855f.jpeg.jpg" alt="Image 1">
                                    <div class="new-card__content">
                                      <p class="new-card__title">SMART EYEWEAR</p>
                                      <p class="new-card__description">Boasting integrated POV display, telemedicine connectivity, voice commands, assisted reality, dual HD cameras, and WiFi support, all while providing essential over-the-shoulder doctor support.</p>
                                    </div>
                                  </div>
                              
                                  <div class="new-card">
                                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Ventilator-150x150-1.png" alt="Image 1">
                                      <!-- Add your SVG path here -->
                                    </svg>
                                    <div class="new-card__content">
                                      <p class="new-card__title">VENTILATOR</p>
                                      <p class="new-card__description"> Advanced respiratory support when it's needed most.</p>
                                      <img src="image2.jpg" alt="Image 2">
                                    </div>
                                  </div>
                              
                                  <div class="new-card">
                                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Blood-gas-analyzer-150x150-2.png" alt="Image 1">
                                      <!-- Add your SVG path here -->
                                    </svg>
                                    <div class="new-card__content">
                                      <p class="new-card__title">AUTOMATIC BLOOD GAS ANALYZER</p>
                                      <p class="new-card__description">Swift, accurate blood analysis for critical insights.</p>
                                      <img src="image3.jpg" alt="Image 3">
                                    </div>
                                  </div>
                              
                                  <div class="new-card">
                                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Smart-Al-Camera.png" alt="Image 1">
                                      <!-- Add your SVG path here -->
                                    </svg>
                                    <div class="new-card__content">
                                      <p class="new-card__title">SMART AI CAMERA</p>
                                      <p class="new-card__description">Harnessing AI for enhanced diagnostics and monitoring.</p>
                                      <img src="image4.jpg" alt="Image 4">
                                    </div>
                                  </div>
                                </div>
                              
                                <div class="row">
                                    <div class="new-card">
                                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Patient-monitor-150x150-1.png" alt="Image 1">
                                        <div class="new-card__content">
                                          <p class="new-card__title">PATIENT MONITOR</p>
                                          <p class="new-card__description">Real-time monitoring for improved patient care.</p>
                                        </div>
                                      </div>
                                  
                                      <div class="new-card">
                                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Syringe-pump-150x150-1.png" alt="Image 1">
                                          <!-- Add your SVG path here -->
                                        </svg>
                                        <div class="new-card__content">
                                          <p class="new-card__title">SYRINGE PUMPS</p>
                                          <p class="new-card__description">Accurate and controlled medication delivery.</p>
                                          <img src="image2.jpg" alt="Image 2">
                                        </div>
                                      </div>
                                  
                                      <div class="new-card">
                                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Defibrillator-150x150-1.png" alt="Image 1">
                                        <div class="new-card__content">
                                          <p class="new-card__title">DEFIBRILLATORr</p>
                                          <p class="new-card__description">Life-saving intervention in critical situations.</p>
                                          <img src="image3.jpg" alt="Image 3">
                                        </div>
                                      </div>
                                  
                                      <div class="new-card">
                                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Point-of-care-devices-150x150-1.png" alt="Image 1">
                                        <div class="new-card__content">
                                          <p class="new-card__title">POINT OF CARE DEVICES</p>
                                          <p class="new-card__description">Bringing diagnostics closer to the patient.</p>
                                          <img src="image4.jpg" alt="Image 4">
                                        </div>
                                      </div>
                                    </div>
                                </div>
                              </div>
                              
                              
                              
                              <!-- Repeat the structure for cards 3 to 6 with different content and images -->
                              
                              
                              
                        </div>
                    </section>
       
                    <section class="section bg-white" id="section5">
                        <div class="process-heading text-center mb-5 text-danger">
                            <h3 class="text-uppercase"><b>NEWS & Updates</b></h3>
                            <p class="text-muted" > </p>
                        </div>
                        <div class="container h-100 d-flex align-items-center">
                            <div class="row">
                                <div class="col-lg-4 col-md-6 vv">
                                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Screenshot-2023-06-22-at-1.39.07-AM-1536x863-1.png" class="rounded img-fluid">
                                    <h5 class="mb-3 mt-5">Kerala:Aluva to start first AR Ambulance</h5>
                                    <!-- <p class="mb-4 text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ut mattis metus, id accumsan erat.</p>
                                    <a href="" class="btn btn-link">View More &rarr;</a> -->
                                    </div>
                                    <div class="col-lg-4 col-md-6 vv">
                                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/img4.png" class="rounded img-fluid">
                                    <h5 class="mb-3 mt-5">Indias 1st Assisted reality enabled smart ambulance launched</h5>
                                     <!-- <p class="mb-4 text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ut mattis metus, id accumsan erat.</p>
                                    <a href="" class="btn btn-link">View More &rarr;</a> -->
                                    </div>
                                    <div class="col-lg-4 col-md-6 vv">
                                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/image3.png" class="rounded img-fluid">
                                        <h5 class="mb-3 mt-5">Indias 1st Assisted reality enabled smart ambulance launched</h5>
                                         <!-- <p class="mb-4 text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ut mattis metus, id accumsan erat.</p>
                                        <a href="" class="btn btn-link">View More &rarr;</a> -->
                                        </div>
                                <div class="col-lg-4 col-md-6 vv">
                                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Screenshot-2023-06-22-at-1.39.49-AM-1536x863-1.png" class="rounded img-fluid">
                                    <h5 class="mb-3 mt-5">Aster Medicity implements  India's first Assisted Reality enabled smart ambulance launched</h5>
                                   <!-- <p class="mb-4 text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ut mattis metus, id accumsan erat.</p>
                                    <a href="" class="btn btn-link">View More &rarr;</a> -->
                                    </div>
                            </div>
                        </div>
                    </section>
            
                    <section class="section bg-white text-center col-md-6 mx-auto" id="section6">
                        <div class="row">
                            <div class="unique-card">
                              
                              <div class="unique-bg">
                                <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/marsleeva-1.jpg" alt="Image 1">
                              </div>
                              <div class="unique-blob"></div>
                            </div>
                          
                            <div class="unique-card">
                              
                              <div class="unique-bg">
                                <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/human-care-Logo-1-1.png" alt="Image 2">
                              </div>
                              <div class="unique-blob"></div>
                            </div>
                          
                            <div class="unique-card">
                             
                              <div class= "unique-bg">
                                <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/blueindia-1.jpg" alt="Image 3">
                              </div>
                              <div class="unique-blob"></div>
                            </div>
                          
                            <div class="unique-card">
                              
                              <div class="unique-bg"><img src="http://theapothecary.co.in/wp-content/uploads/2023/10/bcmedicalcollege-1.jpg" alt="Image 4"></div>
                              <div class="unique-blob"></div>
                            </div>
                          
                            <div class="unique-card">
                              
                              <div class="unique-bg">
                                <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/zhl-1.jpg" alt="Image 5">
                              </div>
                              <div class="unique-blob"></div>
                            </div>

                            <div class="unique-card">
                                
                                <div class="unique-bg">
                                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/aster-dm-healthcare-logo-vector-1.png" alt="Image 5">
                                </div>

                                <div class="unique-blob"></div>
                              </div>
                          </div>
                          
                          
                          
                    </section>

<br>
    <br>
    <br>
    <br>
    <br>
    <div class="fixed-icons">
        <a href="tel:YOUR_PHONE_NUMBER" class="btn btn-primary btn-floating">
          <i class="fas fa-phone"></i>
        </a>
        <a href="https://api.whatsapp.com/send?phone=YOUR_WHATSAPP_NUMBER" class="btn btn-success btn-floating">
          <i class="fab fa-whatsapp"></i>
        </a>
      </div>
</main>

<?php get_footer(); ?>
