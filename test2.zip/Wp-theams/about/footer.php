    <footer>
        <!-- Your site's footer content goes here -->
    </footer>
    <?php wp_footer(); ?>
</body>
</html>
