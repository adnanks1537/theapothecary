// Enqueue Bootstrap CSS
function enqueue_bootstrap_css() {
    wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css');
}
add_action('wp_enqueue_scripts', 'enqueue_bootstrap_css');

// Register Navigation Menu
function register_theme_menus() {
    register_nav_menus(array(
        'header-menu' => __('Header Menu', 'yourtheme'),
    ));
}
add_action('init', 'register_theme_menus');
