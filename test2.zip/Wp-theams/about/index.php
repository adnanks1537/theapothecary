<?php
get_header(); // Include the header
?>


<header>
        <nav class="navbar navbar-expand-lg navbar-dark">
            <a class="navbar-brand" href="#">
                <img src="pictures/Apothecary-Ambulance-Logo.png" alt="Logo" width="200" height="40">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link text-dark" href="index.html">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-dark" href="product.html">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-dark" href="contact.html">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-dark" href="testimonials.html">Testimonials & News</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <br>
    <br>

    <section class="team">
        <h1 class="text-center">OUR TEAM</h1>
        <br>
        <h3 class="text-center text-secondary text-xs">The Apothecary Team</h3>
        <br>

        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card team-card">
                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/doctor-nadeem-shah-1.jpg" class="card-img-top" alt="Team Member 2">
                        <div class="card-body">
                            <h5 class="card-title">Dr Nadeem Hamzath</h5>
                            <p class="card-text">Founder CEO and MD</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 mb-4">
                    <div class="card team-card">
                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Muneeb-Abdul-Majeed-1-1.jpg" class="card-img-top" alt="Team Member 1">
                        <div class="card-body">
                            <h5 class="card-title">Muneeb Abdul Majeed</h5>
                            <p class="card-text">Director-Operations</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 mb-4">
                    <div class="card team-card">
                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Hyder-Shehansha-T-A-1.jpg-1.jpg" class="card-img-top" alt="Team Member 2">
                        <div class="card-body">
                            <h5 class="card-title">Hyder Shehansha T A</h5>
                            <p class="card-text">Director - Marketing</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 mb-4">
                    <div class="card team-card">
                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/Afritha-Syed-1-1.jpg" class="card-img-top" alt="Team Member 2">
                        <div class="card-body">
                            <h5 class="card-title">Afritha Syed</h5>
                            <p class="card-text">Manager - Finance</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 mb-4 ml-auto">
                    <div class="card team-card">
                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/1-1.jpg" class="card-img-top" alt="Team Member 2">
                        <div class="card-body">
                            <h5 class="card-title">Murshida Muneeb</h5>
                            <p class="card-text">Cheif - Paramedic</p>
                        </div>
                    </div>
                </div>

    </section>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/5.9.55/css/materialdesignicons.min.css" integrity="sha512-vIgFb4o1CL8iMGoIF7cYiEVFrel13k/BkTGvs0hGfVnlbV6XjAA0M0oEHdWqGdAVRTDID3vIZPOHmKdrMAUChA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<!--start team-->
<section class="section bg-team">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
               <div class="text-center mb-3">
                    <h3></b>Our <span class="sub-title fw-normal">Associates</span> <b></b></h3>
                   <!-- <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>-->
                </div> 
            </div><!--end col-->
        </div><!--end row-->
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="team-box card border-0 mt-4 bg-transparent">
                    <div class="team-img">
                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/aster-dm-healthcare-logo-vector-1.png" alt="img1" class="img-fluid position-relative">
                        <div class="team-social">
                            <p class="text-white f-14"></p>
                            <ul class="list-inline">
                                <li class="list-inline-item"><a href="#" class="social-link text-primary"><i class="mdi mdi-facebook"></i></a></li>
                                <li class="list-inline-item mx-1"><a href="#" class="social-link text-primary"><i class="mdi mdi-twitter"></i></a></li>
                                <li class="list-inline-item"><a href="#" class="social-link text-primary"><i class="mdi mdi-skype"></i></a></li>
                            </ul> 
                        </div><!--end team-social-->  
                    </div><!--end team-img-->
                    <div class="card-body text-center">
                        <a href="#" class="team-name"><h6 class="mb-1 sub-title"></h6></a>
                        <p class="mb-0 text-muted f-15"></p>
                    </div><!--end card-body-->
                </div><!--end team-box-->
            </div><!--end col-->
            <div class="col-lg-3 col-md-6">
                <div class="team-box card border-0 mt-4 bg-transparent">
                    <div class="team-img">
                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/zhl-1.jpg" alt="img1" class="img-fluid">
                        <div class="team-social">
                            <p class="text-white f-14">.</p>
                            <ul class="list-inline">
                                <li class="list-inline-item"><a href="#" class="social-link text-primary"><i class="mdi mdi-facebook"></i></a></li>
                                <li class="list-inline-item mx-1"><a href="#" class="social-link text-primary"><i class="mdi mdi-twitter"></i></a></li>
                                <li class="list-inline-item"><a href="#" class="social-link text-primary"><i class="mdi mdi-skype"></i></a></li>
                            </ul> 
                        </div><!--end team-social-->   
                    </div><!--end team-img-->
                    <div class="card-body text-center">
                        <a href="#" class="team-name"><h6 class="mb-1 sub-title"></h6></a>
                        <p class="mb-0 text-muted f-15"></p>
                    </div><!--end card-body-->
                </div><!--end team-box-->
            </div><!--end col-->
            <div class="col-lg-3 col-md-6">
                <div class="team-box card border-0 mt-4 bg-transparent">
                    <div class="team-img">
                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/human-care-Logo-1-1.png" alt="img1" class="img-fluid">
                        <div class="team-social">
                            <p class="text-white f-14"></p>
                            <ul class="list-inline">
                                <li class="list-inline-item"><a href="#" class="social-link text-primary"><i class="mdi mdi-facebook"></i></a></li>
                                <li class="list-inline-item mx-1"><a href="#" class="social-link text-primary"><i class="mdi mdi-twitter"></i></a></li>
                                <li class="list-inline-item"><a href="#" class="social-link text-primary"><i class="mdi mdi-skype"></i></a></li>
                            </ul> 
                        </div><!--end team-social--> 
                    </div><!--end team-img-->
                    <div class="card-body text-center">
                        <a href="#" class="team-name"><h6 class="mb-1 sub-title"></h6></a>
                        <p class="mb-0 text-muted f-15"></p>
                    </div><!--end card-body-->
                </div><!--end team-box-->
            </div><!--end col-->
            <div class="col-lg-3 col-md-6">
                <div class="team-box card border-0 mt-4 bg-transparent">
                    <div class="team-img">
                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/blueindia-1.jpg" alt="img1" class="img-fluid">
                        <div class="team-social">
                            <p class="text-white f-14"></p>
                            <ul class="list-inline">
                                <li class="list-inline-item"><a href="#" class="social-link text-primary"><i class="mdi mdi-facebook"></i></a></li>
                                <li class="list-inline-item mx-1"><a href="#" class="social-link text-primary"><i class="mdi mdi-twitter"></i></a></li>
                                <li class="list-inline-item"><a href="#" class="social-link text-primary"><i class="mdi mdi-skype"></i></a></li>
                            </ul> 
                        </div><!--end team-social-->    
                    </div><!--end team-img-->
                    <div class="card-body text-center">
                        <a href="#" class="team-name"><h6 class="mb-1 sub-title"></h6></a>
                        <p class="mb-0 text-muted f-15"></p>
                    </div><!--end card-body-->
                </div><!--end team-box-->
            </div><!--end col-->
            <div class="col-lg-3 col-md-6">
                <div class="team-box card border-0 mt-4 bg-transparent">
                    <div class="team-img">
                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/human-care-Logo-1-1.png" alt="img1" class="img-fluid position-relative">
                        <div class="team-social"></p>
                            <ul class="list-inline">
                                <li class="list-inline-item"><a href="#" class="social-link text-primary"><i class="mdi mdi-facebook"></i></a></li>
                                <li class="list-inline-item mx-1"><a href="#" class="social-link text-primary"><i class="mdi mdi-twitter"></i></a></li>
                                <li class="list-inline-item"><a href="#" class="social-link text-primary"><i class="mdi mdi-skype"></i></a></li>
                            </ul> 
                        </div><!--end team-social--> 
                    </div><!--end team-img-->
                    <div class="card-body text-center">
                        <a href="#" class="team-name"><h6 class="mb-1 sub-title"></h6></a>
                        <p class="mb-0 text-muted f-15"></p>
                    </div><!--end card-body-->
                </div><!--end team-box-->
            </div><!--end col-->
            <div class="col-lg-3 col-md-6">
                <div class="team-box card border-0 mt-4 bg-transparent">
                    <div class="team-img">
                        <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/marsleeva-1.jpg" alt="img1" class="img-fluid">
                        <div class="team-social">
                            <p class="text-white f-14"></p>
                            <ul class="list-inline">
                                <li class="list-inline-item"><a href="#" class="social-link text-primary"><i class="mdi mdi-facebook"></i></a></li>
                                <li class="list-inline-item mx-1"><a href="#" class="social-link text-primary"><i class="mdi mdi-twitter"></i></a></li>
                                <li class="list-inline-item"><a href="#" class="social-link text-primary"><i class="mdi mdi-skype"></i></a></li>
                            </ul> 
                        </div><!--end team-social-->   
                    </div><!--end team-img-->
                    <div class="card-body text-center">
                        <a href="#" class="team-name"><h6 class="mb-1 sub-title"></h6></a>
                        <p class="mb-0 text-muted f-15"></p>
                    </div><!--end card-body-->
                </div><!--end team-box-->
            </div><!--end col-->                     
</section>

<?php
get_footer(); // Include the footer
