<?php
/* Template Name: Custom Front Page */
get_header();
?>


<main>
                <section class="section video-section" id="section1">
    <video autoplay loop muted poster="your-poster-image.jpg">
        <source src="http://theapothecary.co.in/wp-content/uploads/2023/10/apoc-002.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>
    <div class="container h-100 d-flex align-items-center">
        <div class="row">
            <div class="col-lg-6">
                <!-- Left side of the section (video background) -->
            </div>
            <div class="col-lg-6 d-flex flex-column align-items-center justify-content-center">
                <!-- Right side of the section (text, image, and button) -->
                <div class="text-center mb-5 position:relative">
                    <img src="your-image.png" alt="Image" style="width: 100px; height: 100px;">
                    <div class="process-heading text-center text-danger">
                        <h3 class="text-uppercase"><b>Key Features</b></h3>
                        <p class="text-muted"></p>
                    </div>
                    <a href="learn-more-link" class="btn btn-primary">Learn More</a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="use-cases-section" style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/bg2.jpg');">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <div class="card-use-cases">
                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/AMBULANCE-VEIW-1.jpg" class="card-img-top">
                    <div class="card-body d-flex flex-column align-items-center justify-content-center">
                        <h5 class="card-title text-danger"><b>Road Ambulance</b></h5>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <div class="card-use-cases">
                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/HELICOPTOR-1.jpg" class="card-img-top">
                    <div class="card-body d-flex flex-column align-items-center justify-content-center">
                        <h5 class="card-title text-danger"><b>Air Ambulacne</b></h5>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <div class="card-use-cases">
                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/WATERAMBULANCE-1.jpg" class="card-img-top">
                    <div class="card-body d-flex flex-column align-items-center justify-content-center">
                        <h5 class="card-title text-danger"><b>Water Ambulance</b></h5>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <div class="card-use-cases">
                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/MOBILEACCESS-1.jpg" class="card-img-top">
                    <div class="card-body d-flex flex-column align-items-center justify-content-center">
                        <h5 class="card-title text-danger"><b>Smart Emergency</b></h5>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <div class="card-use-cases">
                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/MOBILEACCESS-1.jpg" class="card-img-top">
                    <div class="card-body d-flex flex-column align-items-center justify-content-center">
                        <h5 class="card-title text-danger"><b>Tele ICU</b></h5>
                    </div>
                </div>
            </div>

           <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <div class="card-use-cases">
                    <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/SMARTICU-1.jpg" class="card-img-top">
                    <div class="card-body d-flex flex-column align-items-center justify-content-center">
                        <h5 class="card-title text-danger"><b>Smart Clinics</b></h5>
                    </div>
                </div>
            </div>
            <!-- Repeat the above card structure for other use cases as needed -->
        </div>
    </div>
</section>

<section class="section video-section" id="section3">
    <video autoplay loop muted poster="<?php echo get_template_directory_uri(); ?>/your-poster-image.jpg" id="bgVideo">
        <source src="<?php echo get_template_directory_uri(); ?>/bg/ecgpulse.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>
    <div class="container h-100 d-flex align-items-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <div class="process-heading text-center mb-5 text-danger">
                        <h3 class="text-uppercase"><b>Key Features</b></h3>
                        <p class="text-muted"> </p>
                    </div>
                </div><!--end col-->
            </div><!--end row-->
            <div class="row">
                <div class="col-lg-12">
                    <div class="process-line position-relative">
                        <div class="row">
                            <!-- Repeat this process-box for other items -->
                            <div class="col-lg-3 col-md-6">
                                <div class="process-box card text-center border-0 mt-4" style="height: 95%;">
                                    <div class="mb-3 pb-2">
                                        <img src="<?php echo get_template_directory_uri(); ?>/key-features/aitech.jpg" alt="01"
                                            class="img-fluid">
                                    </div>
                                    <div class="process-icon f-24">
                                        <i class="mdi mdi-chevron-double-right"></i>
                                    </div>
                                    <a href="#" class ="process-title text-uppercase mt-3">
                                        <h6>Creative Design</h6>
                                    </a>
                                    <div class="card-body rounded mt-3 border py-4">
                                        <p class="text-muted mb-0">Phasellus ullamcorper orci nec arcu accumsan,
                                            ac bibendum nulla volutpat. Nunc purus risus, efficitur nec
                                            efficitur purus.</p>
                                    </div>
                                </div><!--end process-box-->
                            </div><!--end col-->
                            <!-- Repeat this process-box for other items -->
                        </div><!--end row-->
                    </div><!--end process-line-->
                </div><!--end col-->
            </div><!--end row-->
        </div><!--end container-->
    </div><!--end container-->
</section>

<section>
    <div class="container center-content">
        <div class="process-heading text-center mb-5 text-danger">
            <h3 class="text-uppercase"><b>Our Associates</b></h3>
            <p class="text-muted"> </p>
        </div>
        <h1>Center Aligned PNGs</h1>
        <div class="row">
            <div class="col-md-4">
                <img src="<?php echo get_template_directory_uri(); ?>/associates/Allied.jpg" alt="Image 1" class="small-icon">
            </div>
            <div class="col-md-4">
                <img src="<?php echo get_template_directory_uri(); ?>/associates/GE Healthcare logo.PNG" alt="Image 2" class="small-icon">
            </div>
            <div class="col-md-4">
                <img src="<?php echo get_template_directory_uri(); ?>/associates/mindrya.png" alt="Image 3" class="small-icon">
            </div>
            <div class="col-md-4">
                <img src="<?php echo get_template_directory_uri(); ?>/associates/philips.png" alt="Image 3" class="small-icon">
            </div>
            <div class="col-md-4">
                <img src="<?php echo get_template_directory_uri(); ?>/associates/Xperteye logo.PNG" alt="Image 3" class="small-icon">
            </div>
        </div>
    </div>
</section>

<section class="section bg-danger key-features-section" style="position: relative;" id="section4">
    <div class="process-heading text-center mb-5 text-white">
        <h3 class="text-uppercase"><b>Integrated Devices</b></h3>
        <p class="text-muted"> </p>
    </div>
    <div class="container h-100 d-flex align-items-center">
        <div class="card-container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
                    <div class="new-card text-center">
                        <img src="<?php echo get_template_directory_uri(); ?>/devices/Smart-eyewear-150x150.png" alt="Image 1">
                        <div class="new-card__content">
                            <p class="new-card__title">Card Title 1</p>
                            <p class="new-card__description">Description for Card 1.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
                    <div class="new-card text-center">
                        <img src="<?php echo get_template_directory_uri(); ?>/devices/Blood-gas-analyzer-150x150 (1).png" alt="Image 1">
                        <div class="new-card__content">
                            <p class="new-card__title">Card Title 2</p>
                            <p class="new-card__description">Description for Card 2.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
                    <div class "new-card text-center">
                        <img src="<?php echo get_template_directory_uri(); ?>/devices/Defibrillator-150x150.png" alt="Image 1">
                        <div class="new-card__content">
                            <p class="new-card__title">Card Title 3</p>
                            <p class="new-card__description">Description for Card 3.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
                    <div class="new-card text-center">
                        <img src="<?php echo get_template_directory_uri(); ?>/devices/Hand Held Ultrasound.PNG" alt="Image 1">
                        <div class="new-card__content">
                            <p class="new-card__title">Card Title 4</p>
                            <p class="new-card__description">Description for Card 4.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
                    <div class="new-card text-center">
                        <img src="<?php echo get_template_directory_uri(); ?>/devices/patient monitor 02.jpg" alt="Image 1">
                        <div class="new-card__content">
                            <p class="new-card__title">Card Title 4</p>
                            <p class="new-card__description">Description for Card 4.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
                    <div class="new-card text-center">
                        <img src="<?php echo get_template_directory_uri(); ?>/devices/Point-of-care-devices-150x150.png" alt="Image 1">
                        <div class="new-card__content">
                            <p class="new-card__title">Card Title 4</p>
                            <p class="new-card__description">Description for Card 4.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
                    <div class="new-card text-center">
                        <img src="<?php echo get_template_directory_uri(); ?>/devices/Smart Al Camera.PNG" alt="Image 1">
                        <div class="new-card__content">
                            <p class="new-card__title">Card Title 4</p>
                            <p class="new-card__description">Description for Card 4.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
                    <div class="new-card text-center">
                        <img src="<?php echo get_template_directory_uri(); ?>/devices/Syringe-pump-150x150.png" alt="Image 1">
                        <div class="new-card__content">
                            <p class="new-card__title">Card Title 4</p>
                            <p class="new-card__description">Description for Card 4.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section bg-white" id="section5">
    <div class="process-heading text-center mb-5 text-danger">
        <h3 class="text-uppercase"><b>NEWS & Updates</b></h3>
        <p class="text-muted"> </p>
    </div>
    <div class="container h-100 d-flex align-items-center">
        <div class="row">
            <div class="col-lg-4 col-md-6 vv">
                <img src="<?php echo get_template_directory_uri(); ?>/testimonials/news1.png" class="rounded img-fluid">
                <h5 class="mb-3 mt-5">Kerala: Aluva to start first AR Ambulance</h5>
            </div>
            <div class="col-lg-4 col-md-6 vv">
                <img src="<?php echo get_template_directory_uri(); ?>/testimonials/news2.png" class="rounded img-fluid">
                <h5 class="mb-3 mt-5">India's 1st Assisted reality enabled smart ambulance launched</h5>
            </div>
            <div class="col-lg-4 col-md-6 vv">
                <img src="<?php echo get_template_directory_uri(); ?>/testimonials/news3.png" class="rounded img-fluid">
                <h5 class="mb-3 mt-5">India's 1st Assisted reality enabled smart ambulance launched</h5>
            </div>
            <div class="col-lg-4 col-md-6 vv">
                <img src="<?php echo get_template_directory_uri(); ?>/testimonials/news4.png" class="rounded img-fluid">
                <h5 class="mb-3 mt-5">Aster Medicity implements India's first Assisted Reality enabled smart ambulance launched</h5>
            </div>
        </div>
    </div>
</section>


<section>
    <div class="container">
        <h1 class="text-danger text-center">OUR PARTNERS</h1>
        <br>
        <div class="row">
            <div class="col-12">
                <div class="card-deck">
                    <div class="card rounded-3d" style="height: 10rem;">
                        <img src="<?php echo get_template_directory_uri(); ?>/testimonials/aster-dm-healthcare-logo-vector.png" alt="Image 1" class="card-img-top rounded-3d">
                        <div class="card-body">
                            <h5 class="card-title">Card 1</h5>
                            <p class="card-text">This is a cool and attractive card.</p>
                        </div>
                    </div>
                    <div class="card rounded-3d" style="height: 10rem;">
                        <img src="<?php echo get_template_directory_uri(); ?>/testimonials/bcmch-logo.png" alt="Image 2" class="card-img-top rounded-3d">
                        <div class="card-body">
                            <h5 class="card-title">Card 2</h5>
                            <p class "card-text">This is another cool and attractive card.</p>
                        </div>
                    </div>
                    <div class="card rounded-3d" style="height: 10rem;">
                        <img src="<?php echo get_template_directory_uri(); ?>/testimonials/blueindia.jpg" alt="Image 3" class="card-img-top rounded-3d">
                        <div class="card-body">
                            <h5 class="card-title">Card 3</h5>
                            <p class="card-text">This card looks great too.</p>
                        </div>
                    </div>
                    <div class="card rounded-3d" style="height: 10rem;">
                        <img src="<?php echo get_template_directory_uri(); ?>/testimonials/human-care-Logo-1.png" alt="Image 4" class="card-img-top rounded-3d">
                        <div class="card-body">
                            <h5 class="card-title">Card 4</h5>
                            <p class="card-text">Yet another cool card.</p>
                        </div>
                    </div>
                    <div class="card rounded-3d" style="height: 10rem;">
                        <img src="<?php echo get_template_directory_uri(); ?>/testimonials/marsleeva.jpg" alt="Image 5" class="card-img-top rounded-3d">
                        <div class="card-body">
                            <h5 class="card-title">Card 5</h5>
                            <p class="card-text">This card is awesome.</p>
                        </div>
                    </div>
                    <div class="card rounded-3d" style="height: 10rem;">
                        <img src="<?php echo get_template_directory_uri(); ?>/testimonials/zhl.jpg" alt="Image 6" class="card-img-top rounded-3d">
                        <div class="card-body">
                            <h5 class="card-title">Card 6</h5>
                            <p class="card-text">One more cool card for you.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<br>
    <br>
    <br>
    <br>
    <br>
    <div class="fixed-icons">
        <a href="tel:YOUR_PHONE_NUMBER" class="btn btn-primary btn-floating">
          <i class="fas fa-phone"></i>
        </a>
        <a href="https://api.whatsapp.com/send?phone=YOUR_WHATSAPP_NUMBER" class="btn btn-success btn-floating">
          <i class="fab fa-whatsapp"></i>
        </a>
      </div>
</main>

<?php get_footer(); ?>
