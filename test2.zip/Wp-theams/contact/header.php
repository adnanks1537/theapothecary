<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <title><?php bloginfo('name'); ?> - <?php bloginfo('description'); ?></title>
    <?php wp_head(); ?>
    <style>
        body {
            background-color: white;
        }
        .row {
            align-items: center;
        }
        .footer-bg {
            background-color: #343a40;
        }
        .red-text {
            color: red;
        }
    </style>
</head>
<body>
    <header class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="<?php echo home_url(); ?>">
                <img src="<?php echo get_template_directory_uri(); ?>/images/Asset 5.png" alt="Logo" width="50">
            </a>
            <!-- Add your navigation menu here -->
            <?php
            wp_nav_menu(array(
                'theme_location' => 'header-menu',
                'container_id'   => 'navbarNav',
                'menu_class'     => 'navbar-nav',
            ));
            ?>
        </div>
    </header>
