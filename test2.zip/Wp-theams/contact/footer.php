<footer class="footer-bg fixed-bottom" style="height: 8rem; background-color: #fff;">
        <div class="container">
            <div class="row">
                <div class="col">
                    <a href="https://www.amaxperteye.com/"><img src="images/Xperteye logo.PNG" alt="Icon 1" width="100" height="100"></a>
                </div>
                <div class="col">
                    <a href="https://www.gehealthcare.in/"><img src="images/GE Healthcare logo.PNG" alt="Icon 2" width="100" height="100"></a>
                </div>
                <div class="col">
                    <a href="link3.html"><img src="images/Allied logo 01.JPG" alt="Icon 3" width="100" height="100"></a>
                </div>
                <div class="col">
                    <a href="https://www.mindray.com/in/"><img src="pictures/mindray.png" alt="Icon 4" width="100" height="100"></a>
                </div>
                <div class="col">
                    <a href="https://www.philips.co.in/"><img src="pictures/philips.png" alt="Icon 5" width="100" height="100"></a>
                </div>
            </div>
        </div>
    </footer>

    </footer>
    <?php wp_footer(); ?>
</body>
</html>
