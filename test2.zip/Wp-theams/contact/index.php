<?php
get_header(); // Include the header
?>

< <main class="container mt-5">
        <div class="row">
            <div class="col-md-4">
                <img src="http://theapothecary.co.in/wp-content/uploads/2023/10/SMARTICU-2.jpgg" alt="About Us Image" class="img-fluid">
            </div>
            <br>
            <br>
            <br>
            <div class="col-md-8">
                <h1 class="red-text">About Us</h1>
                <p class="red-text">
                    "Welcome to Apothecary, your gateway to the future of lifesaving technology. At Apothecary, we merge cutting-edge innovation with our state-of-the-art 5G ambulance service. This isn't just transportation; it's a beacon of hope, ensuring rapid and effective medical care precisely when it's needed most. Our passionate team of paramedics and tech experts shares a common purpose: to revolutionize emergency medical services and elevate patient outcomes. Come embark on this exceptional journey with us, where we leverage the power of 5G technology to deliver advanced healthcare, securing higher chances of survival in critical moments. Discover how Apothecary is changing the game in emergency medical services."
                </p>
                <p class="red-text">
                    Apothecary Medical Services LLP <br>
                    M01-APOC, 1/823/B, Metavalley Tbi, Mes <br>
                    College, Marampilly, Aluva, Ernakulam <br>
                    683105 <br>
                </p>
                <p class="red-text">
                    Follow us on social media:
                    <a href="https://www.instagram.com/yourcompany" target="_blank"><i class="fab fa-instagram"></i> Instagram</a>
                    <a href="https://www.facebook.com/yourcompany" target="_blank"><i class="fab fa-facebook"></i> Facebook</a>
                </p>
                <p class="red-text">
                    Contact Us:
                    <i class="fas fa-phone"></i> +1 (123) 456-7890 <br>
                    <i class="fas fa-globe"></i> <a href="https://www.yourcompany.com" target="_blank">www.yourcompany.com</a> <br>
                    <i class="fas fa-envelope"></i> <a href="mailto:info@yourcompany.com">info@yourcompany.com</a>
                </p>
            </div>
        </div>
    </main>


<?php
get_footer(); // Include the footer
?>
