

// Start typing when the document is ready
document.addEventListener("DOMContentLoaded", typeText);

// Play the video on page load
document.addEventListener("DOMContentLoaded", function () {
    const video = document.getElementById("bgVideo");
    video.play().catch(error => {
        // Autoplay was prevented, handle the error here if needed
    });
    
    // Loop the video
    video.addEventListener("ended", function() {
        this.currentTime = 0;
        this.play();
    });
});
